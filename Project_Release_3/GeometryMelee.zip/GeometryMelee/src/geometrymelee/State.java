/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometrymelee;

/**
 *
 * @author Brian Catter, Jason Dendy
 */
public interface State 
{
    enum StateID
    {
        running,
        paused,
        closing        
    }
    
    public void set(MeleeSim m);
    public StateID checkState();
}
