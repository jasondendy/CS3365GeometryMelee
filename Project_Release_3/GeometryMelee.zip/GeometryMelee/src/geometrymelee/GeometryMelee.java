/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometrymelee;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JMenuItem;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;


import static javax.swing.JFrame.EXIT_ON_CLOSE;
import java.util.ArrayList;
import java.lang.Thread;
import java.awt.event.*;
import javax.swing.SwingUtilities;
/**
 *
 * @author Brian Catter, Jason Dendy
 */
public class GeometryMelee extends JFrame 
        implements ActionListener, ItemListener {
    
    private MeleeSim sim;
    StartState startState = new StartState();
    PausedState pausedState = new PausedState();
    ClosingState closingState = new ClosingState();
    
    public GeometryMelee() {
        
        sim = new MeleeSim();
        pausedState.set(sim);
        JMenu commands;
        
        setName("GEOMETRY MELEE");
        setLayout(new BorderLayout());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(new Dimension(800, 800));
        setBackground(Color.WHITE);
        JMenuBar topMenu = new JMenuBar();
        
        commands = new JMenu("Commands Menu");        
        topMenu.add(commands);
        
        JMenuItem start = new JMenuItem("Start Sim");
        commands.add(start);        
        start.setActionCommand("start");
        start.addActionListener(this);
        
        JMenuItem pause = new JMenuItem("Pause Sim");
        commands.add(pause);        
        pause.setActionCommand("pause");
        pause.addActionListener(this);
        
        JMenuItem reset = new JMenuItem("Reset Sim");
        commands.add(reset);        
        reset.setActionCommand("reset");
        reset.addActionListener(this);
        
        JMenuItem close = new JMenuItem("Close Sim");
        commands.add(close);        
        close.setActionCommand("close");
        close.addActionListener(this);
        
        add(new RenderArea(sim.getListRed(),sim.getListBlack()), 
                BorderLayout.CENTER);
        setJMenuBar(topMenu);
        setVisible(true);
        
        
    }
    
    public void process()
    {
        sim.process();
    }
    
    public boolean quitCheck()
    {
        return sim.quitCheck();
    }
    public boolean runCheck()
    {
        return sim.runCheck();
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if("start" == e.getActionCommand())
        {
            startState.set(sim);
        }
        if("pause" == e.getActionCommand())
        {
            pausedState.set(sim);
        }
        if("reset" == e.getActionCommand())
        {
            pausedState.set(sim);
            sim.populate();
            this.repaint();
        }
        if("close" == e.getActionCommand())
        {
            closingState.set(sim);
        }
    }
    public void itemStateChanged(ItemEvent e)
    {
        //Nothing yet
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        GeometryMelee game = new GeometryMelee();
                
        while(!game.quitCheck())
        {
            if(game.runCheck())
            {
                game.repaint();
                game.process();
            }
            
            
            try
            {
                Thread.sleep(20);
                
            }
            catch(Exception e)
            {
                //There is currently no response to an exception here.
            }
        }
        game.dispose();
    }
    
}

class RenderArea extends JComponent {
    private static final int GRID_GAP = 20;
    
    /*Added */
    private ArrayList<SimObject> toRenderRed, toRenderBlack;
    
    /*End of added*/
    public RenderArea(ArrayList<SimObject> linkToRenderRed, 
            ArrayList<SimObject> linkToRenderBlack) 
    {
        setPreferredSize(new Dimension(800, 800));
        toRenderRed = linkToRenderRed;
        toRenderBlack = linkToRenderBlack;
    }
    
    @Override
    protected void paintComponent(Graphics obj) {
        super.paintComponent(obj);
        
        drawSimObjects(obj);
        
        /* These grid lines are not used in the final version 
        // Vertical lines of grid
        obj.setColor(Color.BLACK);
        obj.drawLine(1  * (GRID_GAP), 0, 1  * (GRID_GAP), 480);
        obj.drawLine(2  * (GRID_GAP), 0, 2  * (GRID_GAP), 480);
        obj.drawLine(3  * (GRID_GAP), 0, 3  * (GRID_GAP), 480);
        obj.drawLine(4  * (GRID_GAP), 0, 4  * (GRID_GAP), 480);
        obj.drawLine(5  * (GRID_GAP), 0, 5  * (GRID_GAP), 480);
        obj.drawLine(6  * (GRID_GAP), 0, 6  * (GRID_GAP), 480);
        obj.drawLine(7  * (GRID_GAP), 0, 7  * (GRID_GAP), 480);
        obj.drawLine(8  * (GRID_GAP), 0, 8  * (GRID_GAP), 480);
        obj.drawLine(9  * (GRID_GAP), 0, 9  * (GRID_GAP), 480);
        obj.drawLine(10 * (GRID_GAP), 0, 10 * (GRID_GAP), 480);
        obj.drawLine(11 * (GRID_GAP), 0, 11 * (GRID_GAP), 480);
        obj.drawLine(12 * (GRID_GAP), 0, 12 * (GRID_GAP), 480);
        obj.drawLine(13 * (GRID_GAP), 0, 13 * (GRID_GAP), 480);
        obj.drawLine(14 * (GRID_GAP), 0, 14 * (GRID_GAP), 480);
        obj.drawLine(15 * (GRID_GAP), 0, 15 * (GRID_GAP), 480);
        obj.drawLine(16 * (GRID_GAP), 0, 16 * (GRID_GAP), 480);
        obj.drawLine(17 * (GRID_GAP), 0, 17 * (GRID_GAP), 480);
        obj.drawLine(18 * (GRID_GAP), 0, 18 * (GRID_GAP), 480);
        obj.drawLine(19 * (GRID_GAP), 0, 19 * (GRID_GAP), 480);
        obj.drawLine(20 * (GRID_GAP), 0, 20 * (GRID_GAP), 480);
        obj.drawLine(21 * (GRID_GAP), 0, 21 * (GRID_GAP), 480);
        obj.drawLine(22 * (GRID_GAP), 0, 22 * (GRID_GAP), 480);
        obj.drawLine(23 * (GRID_GAP), 0, 23 * (GRID_GAP), 480);
        obj.drawLine(24 * (GRID_GAP), 0, 24 * (GRID_GAP), 480);
        obj.drawLine(25 * (GRID_GAP), 0, 25 * (GRID_GAP), 480);
        obj.drawLine(26 * (GRID_GAP), 0, 26 * (GRID_GAP), 480);
        obj.drawLine(27 * (GRID_GAP), 0, 27 * (GRID_GAP), 480);
        obj.drawLine(28 * (GRID_GAP), 0, 28 * (GRID_GAP), 480);
        obj.drawLine(29 * (GRID_GAP), 0, 29 * (GRID_GAP), 480);
        obj.drawLine(30 * (GRID_GAP), 0, 30 * (GRID_GAP), 480);
        obj.drawLine(31 * (GRID_GAP), 0, 31 * (GRID_GAP), 480);
        // Horizontal lines of grid
        obj.drawLine(0, 1  * (GRID_GAP), 640, 1  * (GRID_GAP));
        obj.drawLine(0, 2  * (GRID_GAP), 640, 2  * (GRID_GAP));
        obj.drawLine(0, 3  * (GRID_GAP), 640, 3  * (GRID_GAP));
        obj.drawLine(0, 4  * (GRID_GAP), 640, 4  * (GRID_GAP));
        obj.drawLine(0, 5  * (GRID_GAP), 640, 5  * (GRID_GAP));
        obj.drawLine(0, 6  * (GRID_GAP), 640, 6  * (GRID_GAP));
        obj.drawLine(0, 7  * (GRID_GAP), 640, 7  * (GRID_GAP));
        obj.drawLine(0, 8  * (GRID_GAP), 640, 8  * (GRID_GAP));
        obj.drawLine(0, 9  * (GRID_GAP), 640, 9  * (GRID_GAP));
        obj.drawLine(0, 10 * (GRID_GAP), 640, 10 * (GRID_GAP));
        obj.drawLine(0, 11 * (GRID_GAP), 640, 11 * (GRID_GAP));
        obj.drawLine(0, 12 * (GRID_GAP), 640, 12 * (GRID_GAP));
        obj.drawLine(0, 13 * (GRID_GAP), 640, 13 * (GRID_GAP));
        obj.drawLine(0, 14 * (GRID_GAP), 640, 14 * (GRID_GAP));
        obj.drawLine(0, 15 * (GRID_GAP), 640, 15 * (GRID_GAP));
        obj.drawLine(0, 16 * (GRID_GAP), 640, 16 * (GRID_GAP));
        obj.drawLine(0, 17 * (GRID_GAP), 640, 17 * (GRID_GAP));
        obj.drawLine(0, 18 * (GRID_GAP), 640, 18 * (GRID_GAP));
        obj.drawLine(0, 19 * (GRID_GAP), 640, 19 * (GRID_GAP));
        obj.drawLine(0, 20 * (GRID_GAP), 640, 20 * (GRID_GAP));
        obj.drawLine(0, 21 * (GRID_GAP), 640, 21 * (GRID_GAP));
        obj.drawLine(0, 22 * (GRID_GAP), 640, 22 * (GRID_GAP));
        obj.drawLine(0, 23 * (GRID_GAP), 640, 23 * (GRID_GAP));
       */ 
        
    }
    
    /*Added */
    public void drawSimObjects(Graphics g)
    {
        Color save = g.getColor();
        
        g.setColor(Color.RED);
        for(SimObject s : toRenderRed)
        {
            if(!s.isDead())
            {
                int[] drawPos = s.getPos();
                g.fillOval(drawPos[0], drawPos[1], 16, 16);
            }
        }
        g.setColor(Color.BLACK);
        for(SimObject s : toRenderBlack)
        {
            if(!s.isDead())
            {
                int[] drawPos = s.getPos();
                g.fillRect(drawPos[0], drawPos[1], 16, 16);
            }
        }
        
        g.setColor(save);
    }
    
    /*End of added*/
}
