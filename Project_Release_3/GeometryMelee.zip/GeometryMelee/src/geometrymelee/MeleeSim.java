/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometrymelee;

import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author Jason Dendy, Brian Catter
 */
public class MeleeSim
{
    /* State pattern implementation code begins here*/
    private State state; 
    
    public void SetState(State s)
    {
        this.state = s;
    }
    public boolean quitCheck()
    {
        return State.StateID.closing == state.checkState();
    }
    public boolean runCheck()
    {
        return State.StateID.running == state.checkState();
    }
    
    /*
    Pattern implementation code ends here
    ---------------------------------------
    ---------------------------------------*/
    ArrayList<SimObject> objectsRed, objectsBlack; 
    Random ran = new Random();
    
    public ArrayList<SimObject> getListRed()
    {
        return objectsRed;
    }
    public ArrayList<SimObject> getListBlack()
    {
        return objectsBlack;
    }
    
    public MeleeSim()
    {
        objectsRed = new ArrayList<SimObject>();
        objectsBlack = new ArrayList<SimObject>();
        
        populate();
        
    }
    
    
    
    public void process()
    {
        
        
        for(SimObject r : objectsRed)
        {
            r.wiggle();
            for(SimObject b : objectsBlack)
            {
                if(r.collide(b))
                {
                    r.die();
                    b.die();
                }
            }
        }
        for(SimObject b : objectsBlack)
        {
            b.wiggle();
        }
    }
    
    public void populate()
    {
        objectsRed.clear();
        objectsBlack.clear();
        for(int i = 0; i < 30; ++i)
        {
            Shape s1 = new Shape(ran.nextFloat()* 800, ran.nextFloat()*800);
            objectsRed.add(s1);
            Shape s2 = new Shape(ran.nextFloat()* 800, ran.nextFloat()*800);
            objectsBlack.add(s2);
        }
    }
    
    //Draw to pixels 0,101 to 800, 500
}
