/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometrymelee;

import java.util.ArrayList;
/**
 *
 * @author Jason Dendy, Brian Catter
 */
public class MeleeSim
{
    /* State pattern implementation code begins here*/
    private State state; 
    
    public void SetState(State s)
    {
        this.state = s;
    }
    public boolean quitCheck()
    {
        return State.StateID.closing == state.checkState();
    }
    public boolean runCheck()
    {
        return State.StateID.running == state.checkState();
    }
    
    /*
    Pattern implementation code ends here
    ---------------------------------------
    ---------------------------------------*/
    ArrayList<SimObject> objects; 
    
    public ArrayList<SimObject> getList()
    {
        return objects;
    }
    
    public MeleeSim()
    {
        objects = new ArrayList<SimObject>();
        
        populate();
        
    }
    
    
    
    public void process()
    {
        for(SimObject s : objects)
        {
            s.wiggle();
        }
    }
    
    public void populate()
    {
        objects.clear();
        for(int i = 0; i < 10; ++i)
        {
            Shape s1 = new Shape(i,i);
            objects.add(s1);
        }
    }
    
    //Draw to pixels 0,101 to 800, 500
}
