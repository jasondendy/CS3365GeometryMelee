/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometrymelee;

import java.util.Random;
/**
 *
 * @author Jason Dendy, Brian Catter
 */
public abstract class SimObject 
{
    protected float posX, posY, velX = 0, velY = 0, rawVel = 0, angle;
    int intX = 0, intY = 0;
    private boolean dead = false;
    
    public int[] getPos()
    {
        int[] ret = new int[2];
        ret[0] = intX;
        ret[1] = intY;
        
        return ret;
    }
    public void nextPos()
    {
        posX += velX;
        posY += velY;
        intX = Math.round(posX);
        intY = Math.round(posY);
    }
    
    public void wiggle()
    {
        Random r = new Random();
        float ran = r.nextFloat();
        
        if(rawVel == 0)
        {
            angle = (float)(ran * 2 * Math.PI);
            rawVel = 1.5f;
        }
        else if(rawVel < 1.0)
        {
            rawVel = 0;
        }
        else if(rawVel < 2.0)
        {
            if(ran < 0.7f)
                rawVel *= 3;
            else
                rawVel *= 0.5;
        }
        else if(rawVel < 4.0)
        {
            if(ran < 0.6f)
                rawVel *= 2.5;
            else
                rawVel *= 0.5;
        }
        else if(rawVel < 8.0)
        {
            if(ran < 0.4f)
                rawVel *= 2.0;
            else
                rawVel *= 0.5;
        }
        else if(rawVel < 16.0)
        {
            if(ran < 0.2f)
                rawVel *= 2.5;
            else
                rawVel *= 0.5;
        }
        else 
        {
            rawVel *= 0.5;
        }
        
        velX = (float)Math.cos(angle);
        velY = (float)Math.sin(angle);
        
        this.nextPos();
                    
        if(posX < 0)
            posX = 10;
        if(posX > 800)
            posX = 790;
        if(posY < 0)
            posY = 10;
        if(posY > 800)
            posY = 790;
    }
    
    public boolean collide(SimObject opp)
    {
        int oppPos[] = opp.getPos();
        double distance = Math.sqrt(Math.pow(this.intX - oppPos[0], 2) + 
                Math.pow(this.intY - oppPos[1], 2));
        return distance < 16.0;
    }
    public void die()
    {
        dead = true;
    }
    public boolean isDead()
    {
        return dead;
    }
}
